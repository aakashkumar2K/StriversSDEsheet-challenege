import java.util.*;
class Employee{
	String name;
    int id;
    String office;
	string designation;
	Employee(String name,int id,String office){
		name=new String();
		this.name=name;
		this.id=id;
		office=new String();
		this.office=office;
		designation=new String();
	}
	
	}
}