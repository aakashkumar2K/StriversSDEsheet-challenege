import java.util.*;
interface DBentity{
	
void insert(DBentity var);
void delete(int var);
void update(DBentity var,int v);
default void alter(){
	System.out.println("Implementation is in progress");
}
static DBentity factoryMethod(String s){
	DBentity var;
switch(s){
	case "doctor":
	  var=new doctor();
	  break;
	case "Patient":
      var=new Patient();
    case "Staff":
      var=new Staff();	
	default:
       var=null;	
 }
return var;
}
}