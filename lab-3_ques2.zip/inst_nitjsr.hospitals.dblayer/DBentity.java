import java.util.*;
interface DBentity{
	
void insert(DBentity var);
void delete(int var);
void update(DBentity var,int v);

}