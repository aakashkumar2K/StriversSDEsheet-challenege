class Main{
public static void Main(String [] args){
Employee e=Employee.getEmployee("Developer");
e.insert();
e.delete();
e=Employee.getEmployee("Manager");
e.insert();
e.delete();
}
}