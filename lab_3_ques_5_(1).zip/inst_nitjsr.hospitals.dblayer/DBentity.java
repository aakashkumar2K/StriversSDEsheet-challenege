import java.util.*;
abstract class DBentity{
	
abstract void insert(DBentity var);
abstract void delete(int var);
abstract void update(DBentity var,int v);

}