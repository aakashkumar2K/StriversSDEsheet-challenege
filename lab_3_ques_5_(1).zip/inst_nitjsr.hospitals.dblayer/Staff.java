class Staff extends DBentity{
 void insert(DBentity var){
	 System.out.println("insert method in staff class");
 }
 void delete(int var){
	  System.out.println("delete method in staff class");
 }
void update(DBentity var,int v){
	 System.out.println("update  method in staff class");
}
}