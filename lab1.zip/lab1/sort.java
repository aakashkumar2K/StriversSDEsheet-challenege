import java.util.*;
class sort{
   public static void main(String []args)
   {
    int n=args.length;
	int arr[]=new int[n];
	for(int i=0;i<n;i++){
	arr[i]=Integer.parseInt(args[i]);
	}
	 for(int i=0;i<n;i++){
     System.out.print(arr[i]+" ");
   }
	
	for(int i=1;i<n;i++){
	int k=arr[i];
	int j=i-1;
	while(k<arr[j]&&j>=0){
	   arr[j+1]=arr[j];
	   j--;
	}
	arr[j+1]=k;
	}
   for(int i=0;i<n;i++){
     System.out.print(arr[i]+" ");
   }
  }
}