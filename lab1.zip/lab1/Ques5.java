import java.util.*;
class Ques5{
       public static void main(String [] args){
              int size=args.length;
              int arr[]=new int[size];
             for(int i=0;i<size;i++)
			 {
			   arr[i]=Integer.parseInt(args[i]);
             }
			 int number;
			 System.out.println("enter the number:");
			 Scanner Sc=new Scanner(System.in);
			 number=Sc.nextInt();
			 int flag=0;
			 for(int i=0;i<size;i++){
				 if(arr[i]==number){
					 flag=1;
					 System.out.println("Number is found");
				 }
			 }
			 if(flag==0){
				 System.out.println("number not found");
			 }
			 
 
}
}